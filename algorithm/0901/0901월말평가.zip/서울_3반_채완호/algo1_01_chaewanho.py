T = int(input())
for tc in range(1, T+1):
    word = input()
    result = ''     # 최종 출력 문자열
    stack = []      # .을 기준으로 나눈 문자들을 담아서 역순으로 뽑을 스택

    for i in word:      # 문자열을 문자 별로 차례대로 순회하며
        if i == '.':    # 점을 만나면
            for j in range(len(stack)):     # 그동안 스택에 쌓은 문자들을
                result += stack.pop()       # pop으로 역순으로 result에 대입
            result += i                     # 그리고 .도 대입
        else:
            stack += i                      # 그 외의 경우는 .이 나올때까지 스택에 문자들을 대입해가기

    for k in range(len(stack)):             # 마지막 . 이후에는 result에 대입되지 않기 때문에
        result += stack.pop()

    print(f'#{tc} {result}')
