T = int(input())
for tc in range(1, T+1):
    N, K, E = map(int, input().split())     # N-종점, K-주사위횟수, E-화살표갯수

    # arrow list
    arrow = [0] * (N+1)         # 화살표 내용을 담을 리스트
    for a in range(E):
        q, w = map(int, input().split())     # 화살표 출발과 도착
        arrow[q] = w            # ex) 10 -> 12 , 18 -> 3 , 4 -> 16

    start = 0       # 시작 주사위 칸
    maxi = 0        # 최고도달점
    goal = 0        # 최종도착점

    # 주사위를 K만큼 굴린다
    for i in range(K):
        start = maxi
        for j in range(1, 7):   # 주사위 1~6 까지 돌림
            now = start         # 이전 주사위의 maxi부터 시작
            now += j            # j = 주사위 나온 수
            if now == N:
                goal = now
                break
            if arrow[now]:      # 현재 칸이 화살표 대상이면
                now = arrow[now]    # 이동
            if now > maxi:      # 현재 최고 도달점보다 높다면
                maxi = now
        
        if goal == N:   # gola에 도달한 경우 그대로 출력
            break
            
        goal = maxi     # 그러지 않다면 최고 도달점이 최종 도달점

    print(f'#{tc} {goal}')


